<?php
namespace app\forms;

use std, gui, framework, app;


class level2 extends AbstractForm
{

}