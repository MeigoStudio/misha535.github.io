<?php
namespace app\forms;

use std, gui, framework, app;
use action\Geometry; 


class Proto extends AbstractForm
{

    /**
     * @event cur.step 
     */
    function doCurStep(UXEvent $e = null)
    {
        #Если игрок касается стены
        if (Geometry::intersect($e->sender, $this->instances('Proto.rect')))
        {
            #Тогда удалить игрока, или по проще его убить.
            $e->sender->free();
        }
        
        #Если игрок касается триггера
        if (Geometry::intersect($e->sender, $this->instances('Proto.trigger')))
        {
            #Загружаем сцену level2
            $this->form('game')->game->phys->loadScene('level2');
        }
    }



}
